export type MenuPeriod = 'lunch' | 'dinner';

export type MenuItem = {
  id: string;
  period: MenuPeriod;
  name: string;
  bengali: string;
  description: string;
  priceLabel: string;
  priceMin: number;
  priceMax: number;
  crossedPrice?: number;
  badge?: string;
  portion?: string;
};

export const LUNCH_MENU: MenuItem[] = [
  {
    id: 'veg-thali',
    period: 'lunch',
    name: 'Veg Thali',
    bengali: 'ভেজ থালি',
    description: 'Rice, dal, veg sabzi, bhaja, papad & chutney',
    priceLabel: '₹129',
    priceMin: 129,
    priceMax: 129,
    crossedPrice: 140,
    badge: 'Opening offer · Limited time',
  },
  {
    id: 'egg-thali',
    period: 'lunch',
    name: 'Egg Thali',
    bengali: 'এগ থালি',
    description: 'Rice, dal, egg curry, veg sabzi, bhaja, papad & chutney',
    priceLabel: '₹149',
    priceMin: 149,
    priceMax: 149,
    crossedPrice: 160,
  },
  {
    id: 'fish-thali',
    period: 'lunch',
    name: 'Fish Thali',
    bengali: 'ফিশ থালি',
    description: 'Rice, dal, fish curry, veg sabzi, bhaja, papad & chutney',
    priceLabel: '₹200',
    priceMin: 200,
    priceMax: 200,
    crossedPrice: 220,
  },
  {
    id: 'chicken-thali',
    period: 'lunch',
    name: 'Chicken Thali',
    bengali: 'চিকেন থালি',
    description: 'Rice, dal, chicken curry, veg sabzi, bhaja, papad & chutney',
    priceLabel: '₹229',
    priceMin: 229,
    priceMax: 229,
    crossedPrice: 280,
  },
];

export const DINNER_MENU: MenuItem[] = [
  {
    id: 'plain-ruti',
    period: 'dinner',
    name: 'Plain Ruti',
    bengali: 'সাধারণ রুটি',
    description: 'Per piece',
    priceLabel: '₹4',
    priceMin: 4,
    priceMax: 4,
    portion: 'Plain',
  },
  {
    id: 'butter-ruti',
    period: 'dinner',
    name: 'Butter Ruti',
    bengali: 'বাটার রুটি',
    description: 'Per piece',
    priceLabel: '₹8',
    priceMin: 8,
    priceMax: 8,
    portion: 'Butter',
  },
  {
    id: 'egg-torka',
    period: 'dinner',
    name: 'Egg Torka',
    bengali: 'ডিম তড়কা',
    description: '2 pcs · Confirm your preferred price option when ordering',
    priceLabel: '₹80 / ₹140',
    priceMin: 80,
    priceMax: 140,
  },
  {
    id: 'alur-dom-half',
    period: 'dinner',
    name: 'Alur Dom',
    bengali: 'আলুর দম',
    description: 'Half portion',
    priceLabel: '₹60',
    priceMin: 60,
    priceMax: 60,
    portion: 'Half',
  },
  {
    id: 'alur-dom-full',
    period: 'dinner',
    name: 'Alur Dom',
    bengali: 'আলুর দম',
    description: 'Full portion',
    priceLabel: '₹100',
    priceMin: 100,
    priceMax: 100,
    portion: 'Full',
  },
  {
    id: 'chicken-kosha',
    period: 'dinner',
    name: 'Chicken Kosha',
    bengali: 'চিকেন কষা',
    description: '8 pcs · Please confirm the final price when ordering',
    priceLabel: '₹160–₹180',
    priceMin: 160,
    priceMax: 180,
  },
];

export const ALL_MENU_ITEMS = [...LUNCH_MENU, ...DINNER_MENU];

export const WHATSAPP_NUMBER = '917044714099';

export function getMenuItemOrderName(item: MenuItem) {
  if (item.id.startsWith('alur-dom') && item.portion) {
    return `${item.name} · ${item.portion}`;
  }
  if (item.id === 'egg-torka') return `${item.name} (2 pcs)`;
  if (item.id === 'chicken-kosha') return `${item.name} (8 pcs)`;
  return item.name;
}

export function getMenuItemCartDetail(item: MenuItem) {
  if (item.id === 'plain-ruti' || item.id === 'butter-ruti') {
    return `${item.priceLabel} per piece`;
  }
  if (item.id.startsWith('alur-dom')) return item.priceLabel;
  if (item.id === 'egg-torka') return `2 pcs · ${item.priceLabel}`;
  if (item.id === 'chicken-kosha') return `8 pcs · ${item.priceLabel}`;
  return item.priceLabel;
}

export function formatRupeeRange(min: number, max: number) {
  return min === max ? `₹${min}` : `₹${min}–₹${max}`;
}

export function getWhatsAppOrderUrl(message: string) {
  return `https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(message)}`;
}
