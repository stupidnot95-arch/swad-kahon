import { type ReactNode, useEffect, useState } from 'react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { ErrorBoundary } from '@/components/error-boundary';
import { Toaster } from '@/components/ui/toaster';
import { TooltipProvider } from '@/components/ui/tooltip';
import NotFound from '@/pages/not-found';
import { ArrowDownRight, ArrowRight, Menu, MessageCircle, Minus, Moon, Phone, Plus, ShoppingBag, Sun, X } from 'lucide-react';
import {
  ALL_MENU_ITEMS,
  DINNER_MENU,
  formatRupeeRange,
  getMenuItemCartDetail,
  getMenuItemOrderName,
  getWhatsAppOrderUrl,
  LUNCH_MENU,
} from '@/lib/menu';
import {
  Route,
  Switch,
  useLocation,
  Router as WouterRouter,
} from 'wouter';

const queryClient = new QueryClient();

function Home() {
  const [mobileOpen, setMobileOpen] = useState(false);
  const [cartOpen, setCartOpen] = useState(false);
  const [toast, setToast] = useState('');
  const [basket, setBasket] = useState<Record<string, number>>({});
  const basketCount = Object.values(basket).reduce((total, amount) => total + amount, 0);
  const basketMin = ALL_MENU_ITEMS.reduce(
    (total, item) => total + item.priceMin * (basket[item.id] ?? 0),
    0,
  );
  const basketMax = ALL_MENU_ITEMS.reduce(
    (total, item) => total + item.priceMax * (basket[item.id] ?? 0),
    0,
  );
  const whatsappOrderUrl = getWhatsAppOrderUrl(
    [
      'Hello Swad Kahon, I would like to request this order:',
      ...ALL_MENU_ITEMS.filter((item) => basket[item.id]).map(
        (item) =>
          `• ${getMenuItemOrderName(item)} × ${basket[item.id]} — ${item.priceLabel}`,
      ),
      `Estimated menu subtotal: ${formatRupeeRange(basketMin, basketMax)}`,
      'Please confirm availability, any listed price options, and that my address is within the Barendra Para–Garia delivery area. I understand this order is not confirmed until you reply.',
    ].join('\n'),
  );
  const directWhatsAppUrl = getWhatsAppOrderUrl(
    'Hello Swad Kahon, I am in the Barendra Para–Garia area of Kolkata, West Bengal. Please confirm today’s menu and whether delivery is available at my address.',
  );

  const showToast = (message: string) => {
    setToast(message);
    window.setTimeout(() => setToast(''), 2400);
  };
  const addDish = (id: string) => {
    setBasket((current) => ({ ...current, [id]: (current[id] ?? 0) + 1 }));
    const item = ALL_MENU_ITEMS.find((menuItem) => menuItem.id === id);
    if (item) showToast(`${item.name} added to your order`);
  };
  const changeQuantity = (id: string, change: number) => {
    setBasket((current) => {
      const next = (current[id] ?? 0) + change;
      if (next <= 0) {
        const updated = { ...current };
        delete updated[id];
        return updated;
      }
      return { ...current, [id]: next };
    });
  };
  const renderMenuItems = (items: typeof LUNCH_MENU) =>
    items.map((item) => (
      <article className="menu-item-card" key={item.id} data-testid={`card-menu-item-${item.id}`}>
        <div className="menu-item-info">
          {item.badge && <span className="menu-item-badge">{item.badge}</span>}
          <div className="menu-item-title">
            <div>
              <h4>{item.name}</h4>
              <span className="menu-item-bengali bn">{item.bengali}</span>
            </div>
            <div className="menu-item-price">
              {item.crossedPrice && <del>₹{item.crossedPrice}</del>}
              <strong>{item.priceLabel}</strong>
            </div>
          </div>
          <p>{item.description}</p>
        </div>
        <button
          className="menu-add-button"
          onClick={() => addDish(item.id)}
          aria-label={`Add ${item.name}${item.portion ? ` ${item.portion}` : ''} to your order`}
          data-testid={`button-add-menu-item-${item.id}`}
        >
          <Plus size={15} aria-hidden="true" />
        </button>
      </article>
    ));

  useEffect(() => {
    if (!cartOpen) return;
    const onKeyDown = (event: KeyboardEvent) => {
      if (event.key === 'Escape') setCartOpen(false);
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [cartOpen]);

  return (
    <div className="site-wrap">
      <div className="top-note"><span aria-hidden="true">·</span> বাংলা ঘরের রান্না, মন ভরে খাওয়া <span aria-hidden="true">·</span> A Bengali table, made for the everyday</div>
      <header className="site-header">
        <a className="brand" href="#home" aria-label="Swad Kahon home">
          <img className="brand-logo" src="/images/swad-kahon-logo.jpg" alt="" width={50} height={50} />
          <span><span className="brand-name bn">স্বাদ কাহন</span><span className="brand-sub">A little story of taste</span></span>
        </a>
        <button className="menu-toggle" aria-label={mobileOpen ? 'Close navigation' : 'Open navigation'} aria-expanded={mobileOpen} onClick={() => setMobileOpen((open) => !open)} data-testid="button-mobile-menu">
          {mobileOpen ? <X size={22} /> : <Menu size={22} />}
        </button>
        <nav className={`nav-links${mobileOpen ? ' is-open' : ''}`} aria-label="Main navigation">
          <a href="#menu" onClick={() => setMobileOpen(false)}>The menu</a>
          <a href="#our-kitchen" onClick={() => setMobileOpen(false)}>Our kitchen</a>
          <a href="#good-to-know" onClick={() => setMobileOpen(false)}>Good to know</a>
          <button className="nav-order" onClick={() => { setCartOpen(true); setMobileOpen(false); }} data-testid="button-open-list">Your order <ShoppingBag size={14} /></button>
        </nav>
      </header>

      <main>
        <section className="hero" id="home">
          <div className="hero-copy">
            <div className="eyebrow">Bengali comfort, cooked with care</div>
            <h1><span className="bn">স্বাদের গল্প</span>A taste that<br />feels like home.</h1>
            <p className="hero-lede"><span className="bn">চেনা স্বাদ, যত্ন করে রান্না।</span><br />The familiar flavours of a Bengali home, made for the days you want something special without making a fuss.</p>
            <div className="hero-actions">
              <a className="btn-primary" href="#menu">Meet the menu <ArrowDownRight size={15} /></a>
              <a className="text-link" href={directWhatsAppUrl} target="_blank" rel="noopener noreferrer">Order on WhatsApp</a>
            </div>
            <div className="hero-note"><i aria-hidden="true" /> Slow notes of home, served one plate at a time</div>
          </div>
          <div className="hero-visual">
            <img className="hero-photo" src="/images/hero-bengali-thali.jpg" alt="A generous Bengali meal of fragrant rice and slow-cooked curry" />
            <div className="round-stamp"><span><strong>ঘরের</strong>FLAVOUR<br />FAMILIAR</span></div>
            <div className="photo-caption">Rice first, always.<small>ভাত দিয়ে শুরু</small></div>
          </div>
        </section>

        <div className="marquee" aria-label="Food made with care, familiar Bengali flavours">
          <div className="marquee-track" aria-hidden="true">
            {[0, 1, 2, 3].map((item) => <span key={item}>A LITTLE BENGAL ON YOUR PLATE <b>·</b> ঘরের স্বাদ <b>·</b> FOOD WITH A MEMORY <b>·</b></span>)}
          </div>
        </div>

        <section className="section" id="menu">
          <div className="section-inner">
            <div className="section-head">
              <div><div className="section-kicker">Freshly cooked with love / ভালোবাসা দিয়ে রান্না</div><h2>Lunch & dinner, <span className="bn">মন ভরে।</span></h2></div>
              <p className="section-intro">Choose a homestyle thali at lunch or a comforting favourite for dinner. Every price is shown in Indian rupees.</p>
            </div>
            <div className="menu-cards">
              <section className="menu-panel lunch-panel" aria-labelledby="lunch-menu-title">
                <header className="menu-panel-header lunch-header">
                  <div className="menu-panel-name">
                    <span className="menu-period-icon"><Sun size={21} aria-hidden="true" /></span>
                    <div>
                      <h3 id="lunch-menu-title">Lunch Menu</h3>
                      <span className="menu-panel-bengali bn">দুপুরের মেনু</span>
                    </div>
                  </div>
                  <span className="menu-hours">11:30 AM – 3:00 PM</span>
                </header>
                <div className="menu-panel-list">{renderMenuItems(LUNCH_MENU)}</div>
              </section>

              <section className="menu-panel dinner-panel" aria-labelledby="dinner-menu-title">
                <header className="menu-panel-header dinner-header">
                  <div className="menu-panel-name">
                    <span className="menu-period-icon"><Moon size={21} aria-hidden="true" /></span>
                    <div>
                      <h3 id="dinner-menu-title">Dinner Menu</h3>
                      <span className="menu-panel-bengali bn">রাতের মেনু</span>
                    </div>
                  </div>
                  <span className="menu-hours">6:00 PM – 10:00 PM</span>
                </header>
                <div className="menu-panel-list">{renderMenuItems(DINNER_MENU)}</div>
              </section>
            </div>
            <div className="delivery-strip">
              <div className="delivery-strip-copy">
                <span className="delivery-kicker">Serving Barendra Para to Garia / কলকাতা</span>
                <strong>Delivery is limited to Barendra Para–Garia, Kolkata, West Bengal.</strong>
                <span>Free delivery within 2 km on orders of ₹129 or more. Share your exact address on WhatsApp to confirm coverage.</span>
              </div>
              <a className="delivery-cta" href={directWhatsAppUrl} target="_blank" rel="noopener noreferrer" data-testid="link-whatsapp-menu">
                <MessageCircle size={17} aria-hidden="true" /> Ask on WhatsApp
              </a>
            </div>
          </div>
        </section>

        <section className="section story" id="our-kitchen">
          <div className="section-inner">
            <div className="story-grid">
              <div>
                <div className="section-kicker">From our kitchen / আমাদের রান্নাঘর</div>
                <h2>Not just a meal.<br /><span className="bn">একটু আপন করে।</span></h2>
                <p className="story-text">স্বাদ কাহন means a story of taste. We’re here for the comfort of a familiar Sunday lunch, the brightness of mustard and green chilli, and the small joy of a meal that asks nothing of you but to sit down.<br /><br />Swad Kahon is a Bengali cloud kitchen rooted in home cooking: generous flavours, thoughtful preparation, and a welcome place at the table. Choose a lunch thali or a comforting dinner favourite, then reach us directly to check availability and place your order.</p>
              </div>
              <div className="story-quote">“The best flavours don’t need fuss. They just need to feel like yours.”<small>স্বাদ কাহন · A note from our kitchen</small></div>
            </div>
            <div className="values">
              <div className="value"><strong>Rooted in Bengal</strong><span>Recipes and flavours with a sense of place.</span></div>
              <div className="value"><strong>Comfort, not compromise</strong><span>A familiar table, with thoughtful detail.</span></div>
              <div className="value"><strong>Always a little generous</strong><span>Because the best meals make room for one more.</span></div>
            </div>
          </div>
        </section>

        <section className="section ritual" aria-labelledby="ritual-title">
          <div className="section-inner ritual-grid">
            <div className="ritual-art" aria-label="Decorative Bengali type illustration">
              <div className="ritual-center"><span>the heart of the table</span><strong>ভাত</strong><span>rice · warmth · home</span></div>
            </div>
            <div className="ritual-copy">
              <div className="section-kicker">The little things / ছোট ছোট কথা</div>
              <h2 id="ritual-title">A familiar kind of <span className="bn">ভালোবাসা।</span></h2>
              <p>Every Bengali table has its own rhythm. A first spoon of rice, a little something on the side, a sweet note to finish. We’re inspired by that feeling: food that brings its own warmth to an ordinary day.</p>
              <ul className="ritual-points">
                <li><b>01</b><span>Distinctive Bengali flavours, front and centre.</span></li>
                <li><b>02</b><span>Comforting classics alongside little discoveries.</span></li>
                <li><b>03</b><span>Made for a memorable meal, without the occasion.</span></li>
              </ul>
            </div>
          </div>
        </section>

        <section className="section closing" id="good-to-know">
          <div className="section-inner closing-layout">
            <div>
              <div className="section-kicker">Order & delivery / অর্ডার ও ডেলিভারি</div>
              <h2>Good food, just a message away.</h2>
              <p className="closing-copy">Call or WhatsApp Swad Kahon to check availability, share your address, and confirm your order.</p>
            </div>
            <div className="faq-list">
              <details className="faq-item">
                <summary>When is lunch and dinner served?</summary>
                <div className="faq-answer">The menu lists lunch from 11:30 AM to 3:00 PM and dinner from 6:00 PM to 10:00 PM. Please contact us to confirm today’s availability.</div>
              </details>
              <details className="faq-item">
                <summary>Where do you deliver?</summary>
                <div className="faq-answer">Delivery is limited to the Barendra Para–Garia area of Kolkata, West Bengal; we cannot take orders to distant areas outside it. Free delivery is available within 2 km for orders of ₹129 or more. Send your exact address on WhatsApp so we can confirm coverage and any delivery charges.</div>
              </details>
              <details className="faq-item">
                <summary>How do I place an order?</summary>
                <div className="faq-answer">Add dishes to your order list, then send the request on WhatsApp—or call 7044714099. The kitchen will confirm availability, any price options, delivery, and your final total.</div>
              </details>
            </div>
          </div>
        </section>
      </main>

      <footer className="footer">
        <div className="footer-inner">
          <div className="footer-top">
            <a className="brand" href="#home" aria-label="Swad Kahon, back to top">
              <img className="brand-logo" src="/images/swad-kahon-logo.jpg" alt="" width={56} height={56} />
              <span><span className="brand-name bn">স্বাদ কাহন</span><span className="brand-sub">A little story of taste</span></span>
            </a>
            <div className="footer-note">A little Bengali warmth.<br />A lot of heart on the plate.</div>
            <nav className="footer-links" aria-label="Footer navigation">
              <a href="#menu">Lunch & dinner menu</a><a href="#our-kitchen">Our kitchen</a><a href="#good-to-know">Order & delivery</a>
              <a className="footer-contact-link" href="tel:+917044714099"><Phone size={13} aria-hidden="true" /> 7044714099</a>
            </nav>
          </div>
          <div className="footer-bottom"><span>© {new Date().getFullYear()} স্বাদ কাহন · Swad Kahon</span><span>Lunch 11:30 AM–3:00 PM · Dinner 6:00–10:00 PM</span></div>
        </div>
      </footer>

      {basketCount > 0 && <button className="cart-fab" onClick={() => setCartOpen(true)} aria-label={`Open your order, ${basketCount} ${basketCount === 1 ? 'item' : 'items'}`} data-testid="button-open-order"><ShoppingBag size={16} /> Your order <span className="cart-count">{basketCount}</span></button>}

      {cartOpen && <div className="drawer-backdrop" onMouseDown={(event) => { if (event.target === event.currentTarget) setCartOpen(false); }}>
        <aside className="cart-drawer" role="dialog" aria-modal="true" aria-labelledby="drawer-title">
          <div className="drawer-head"><h2 id="drawer-title">Your order</h2><button className="icon-button" onClick={() => setCartOpen(false)} aria-label="Close order list" data-testid="button-close-order"><X size={21} /></button></div>
          <div className="drawer-disclaimer">Send your order request on WhatsApp. The kitchen will confirm availability, any price options, delivery, and your final total.</div>
          {basketCount === 0 ? <div className="cart-empty">A good meal begins with a little curiosity.<br />Add a dish from the lunch or dinner menu.</div> : <>
            {ALL_MENU_ITEMS.filter((item) => basket[item.id]).map((item) => <div className="cart-row" key={item.id}>
              <div>
                <strong>{getMenuItemOrderName(item)}</strong>
                <small>{getMenuItemCartDetail(item)}</small>
              </div>
              <div className="quantity" aria-label={`${item.name} quantity`}>
                <button onClick={() => changeQuantity(item.id, -1)} aria-label={`Remove one ${item.name}`} data-testid={`button-remove-one-${item.id}`}><Minus size={13} /></button>
                <span>{basket[item.id]}</span>
                <button onClick={() => changeQuantity(item.id, 1)} aria-label={`Add one ${item.name}`} data-testid={`button-add-one-${item.id}`}><Plus size={13} /></button>
              </div>
            </div>)}
            <div className="cart-total"><span>Estimated menu subtotal</span><strong>{formatRupeeRange(basketMin, basketMax)}</strong></div>
            <p className="cart-footnote">Menu subtotal only. Delivery is limited to Barendra Para–Garia, Kolkata, West Bengal. Free within 2 km on orders of ₹129 or more; share your address so the kitchen can confirm delivery and your final total.</p>
            <a className="drawer-whatsapp" href={whatsappOrderUrl} target="_blank" rel="noopener noreferrer" data-testid="link-send-order-whatsapp">
              <MessageCircle size={17} aria-hidden="true" /> Send order request on WhatsApp <ArrowRight size={15} aria-hidden="true" />
            </a>
          </>}
          <a className="drawer-call" href="tel:+917044714099" data-testid="link-call-kitchen"><Phone size={15} aria-hidden="true" /> Call 7044714099</a>
          <button className="drawer-close" onClick={() => setCartOpen(false)} data-testid="button-continue-browsing">Continue exploring</button>
        </aside>
      </div>}
      {toast && <div className="toast-message" role="status" aria-live="polite">{toast}<ArrowRight size={14} style={{ marginLeft: 8, verticalAlign: 'middle' }} /></div>}
    </div>
  );
}

function Router() {
  return (
    // Keep a shared shell (sidebar, navbar) outside the boundary so it
    // survives a page crash.
    <RoutedErrorBoundary>
      <Switch>
        <Route path="/" component={Home} />
        <Route component={NotFound} />
      </Switch>
    </RoutedErrorBoundary>
  );
}

function RoutedErrorBoundary({ children }: { children: ReactNode }) {
  const [location] = useLocation();
  return <ErrorBoundary resetKey={location}>{children}</ErrorBoundary>;
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, '')}>
          <Router />
        </WouterRouter>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
