---
name: Swad Kahon business details
description: User-provided brand, cloud-kitchen type, and delivery-area constraint.
---

The user identifies the business as a cloud kitchen named **স্বাদ কাহন** (Swad Kahon).
Delivery is limited to the Barendra Para–Garia area of Kolkata, West Bengal; far-away locations are outside the service area.

**Why:** The user supplied the business identity and clarified that the kitchen cannot deliver far away.

**How to apply:** Preserve the Bengali spelling, identify it as a cloud kitchen, and state the Barendra Para–Garia delivery boundary without implying coverage beyond it. Do not invent operating hours, contact details, or menu items.
